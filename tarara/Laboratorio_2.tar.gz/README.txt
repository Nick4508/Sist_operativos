Nombre : Sofía Ríos Núñez       ROL : 202104650-K   Paralelo: 200  
Nombre : Gabriel Venegas Ortíz  ROL : 202104676-3   Paralelo: 200 