#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include "tablero.h"
#include "jugador.h"

player *crearPlayer(int p[2], casilla c){
    player* pj = malloc(sizeof(player));
    pj->pos[0] = p[0];
    pj->pos[1] = p[1];
    pj->tesoro = 0;
    pj->cas = c;

    return pj;
} //constructor del struct player

admin* crearAdmin(){
    admin* tiktoker = malloc(sizeof(admin));
    tiktoker->rondasTotal = 15;
    tiktoker->inicioI = 20;
    tiktoker->finI = 24;
    tiktoker->inicioJ = 20;
    tiktoker->finJ = 24;
    tiktoker->camActivasST = 0;
    tiktoker->checkC = crearCamaraCheck();
    tiktoker->checkT = crearTesoroCheck();
    tiktoker->jugadores = (player**) malloc(4*sizeof(player *));

    
    for(int i = 0; i < 9; i++){tiktoker->idEnMazo[i] = 0;}
    //jugadores y mesa pendientes;

    return tiktoker;
};

char *mezclarMazoAccion(){
    srand(time(NULL));

    char* mazo = malloc(sizeof(char)*5);
    int x, i, b = 0, c = 4, e = 0;
    for (i = 0; i < 4; i++) {
        mazo[i] = '\0';
    }
    while (c > 0){
        x = rand() % 1000;
        x = x % 2;
        i = rand() % 1000;
        i = i % 4;
        if(mazo[i] == '\0'){
            if(b < 2 && x == 1){
                mazo[i] = 'B';
                c--;
                b++;
            }
            else if(e < 2 && x == 0){
                mazo[i] = 'E';
                c--;
                e++;
            }
        }
    }
    return mazo;
        
}

void asignarCartas(admin* boss){            //se le asignan las cartas a los jugadores
    char* mazo = mezclarMazoAccion();

    for(int i = 0; i < 4; i++){
        boss->jugadores[i]->card = mazo[i];
    }
};

int buscarPosJ(admin* boss, int i, int j){
    
    for(int k = 0; k < 4; k++){
        if(boss->jugadores[k]->pos[0]==i && boss->jugadores[k]->pos[1]==j){
            //printf("Jugador %d encontrado en la casilla (%d,%d)\n",k+1, i,j);
            return k+1;
        }
    }
    return -1;
};

casilla **crearSuperTablero(admin* boss, int ii){
    tablero* inicio = boss->mazo[ii];
    boss->idEnMazo[ii] = 1;

    casilla **mesa =(casilla**) malloc (45*sizeof(casilla*));

    for (int i = 0; i < 45; i++){
        mesa[i] = (casilla *) malloc(45*sizeof(casilla));
    }

    for (int i = 0; i < 45; i++){

        for (int j = 0; j < 45; j++){
            if ( (i>19 && i<25) && (j>19 && j<25) ){
                mesa[i][j] = inicio->casillas[i-20][j-20];
                
                if(inicio->casillas[i-20][j-20].elem == JUGADOR){
                    int p[2];
                    p[0] = i;
                    p[1] = j;
                    boss->jugadores[ (inicio->casillas[i-20][j-20].numJugador) - 1] = crearPlayer(p,inicio->casillas[i-20][j-20]);
                    mesa[i][j] = crearCasilla('0');
                }

            }
            else{
                mesa[i][j] = crearCasilla('*');
            }
        }

    }
    return mesa;
};

void mostrarSuperTablero(admin* juego){

    int pinpong = 0, pj;
    char c;
    player* aux;

    for(int i=0; i<45; i++){
        for(int j=0; j<45; j++){
            pj = buscarPosJ(juego, i, j);
            if((i >= juego->inicioI && i<= juego->finI) && (j >= juego->inicioJ && j<= juego->finJ) && juego->mesa[i][j].representacion == '*'){
                printf("   ");
                pinpong = 1;
            }//->>>>>> if para imprimir espacios en blanco y que no se descuadre el tablero.
            if(juego->mesa[i][j].representacion != '*'){
                if(pj == -1){
                    if(juego->mesa[i][j].numJugador == -1){

                        if(juego->mesa[i][j].representacion == 'B'){ c = ' ';
                        }else{c = juego->mesa[i][j].repSecundaria;}

                        printf("%c%c ", juego->mesa[i][j].representacion, c);
                    }else{
                        printf("%c%d ", juego->mesa[i][j].representacion, juego->mesa[i][j].numJugador);
                    }
                
                }else{
                    aux = juego->jugadores[pj-1];
                    printf("%c%d ", aux->cas.representacion, aux->cas.numJugador);
                }
                pinpong = 1;
            }
        }
        if(pinpong == 1){
            printf("\n");
            pinpong = 0;
        }
    }
};

void mostrarManoJ(admin* boss, int ii){

    player* jugador = boss->jugadores[ii];
    casilla tmp = boss->mesa[jugador->pos[0]][jugador->pos[1]];

    printf("\nMano del Jugador %d\n", jugador->cas.numJugador);

    printf("    Cartas:\n"
            "       >Movimiento: 'W' 'A' 'S' 'D'\n"
            "       >Especial  : '%c'\n", jugador->card);
    if((tmp.elem == TESORO) && (tmp.numJugador == ii+1)){
        printf("        >Recolectar tesoro : 'R'\n\n");
    }else{
        printf("\n");
    }

};

void addTablero(admin* boss, int indexToAdd, int numJ, char orientacion){      //  numJ = numero del jugador que añade ->recuperar posición;
                                                                // considerar que el buscar se activa estando arriba de él.
    tablero* tabToAdd = boss->mazo[indexToAdd];

    if(boss->checkC->camTab[indexToAdd] == 1){boss->camActivasST += 1;}

    int iPosJ = boss->jugadores[numJ - 1]->pos[0];
    int jPosJ = boss->jugadores[numJ - 1]->pos[1];
    
    int inicioI, finI, inicioJ, finJ, iDiv, jDiv;

    switch (orientacion){
        case 'N':
            boss->inicioI -= 5;
            inicioI = iPosJ-1;
            finI = iPosJ - 6;
            inicioJ = jPosJ - 2;
            finJ = jPosJ + 3;

            iDiv = inicioI/5;
            jDiv = finJ/5 - 1;

            for(int i = inicioI; i > finI; i--){
                //printf("Estado de i: %d\n",i);
                for(int j = inicioJ; j < finJ; j++){
                    //printf("j: %d     ",j);
                    boss->mesa[i][j] = tabToAdd->casillas[i - (iDiv*5)][j - jDiv*5];
                    //printf("\n dentro del tiktok \n");
                }
                printf("\n");
            }            
            break;

        case 'S':
            boss->finI += 5;
            inicioI = iPosJ + 1;
            finI = iPosJ + 6;
            inicioJ = jPosJ - 2;
            finJ = jPosJ + 3;

            iDiv = finI/5 - 1;
            jDiv = finJ/5 - 1;

            for(int i = inicioI; i < finI; i++){
                for(int j = inicioJ; j < finJ; j++){
                    boss->mesa[i][j] = tabToAdd->casillas[i - (iDiv*5)][j - jDiv*5];
                }
            }  
            break;

        case 'E':
            boss->finJ += 5;
            inicioI = iPosJ - 2;
            finI = iPosJ + 3;
            inicioJ = jPosJ + 1;
            finJ = jPosJ + 6;

            iDiv = finI/5 - 1;
            jDiv = finJ/5 - 1;

            for(int i = inicioI; i < finI; i++){
                for(int j = inicioJ; j < finJ; j++){
                    boss->mesa[i][j] = tabToAdd->casillas[i - (iDiv*5)][j - jDiv*5];
                }
            }  
            break;

        case 'W':
            boss->inicioJ -= 5;
            inicioI = iPosJ - 2;
            finI = iPosJ + 3;
            inicioJ = jPosJ - 1;
            finJ = jPosJ - 6;

            iDiv = finI/5 - 1;
            jDiv = inicioJ/5;

            for(int i = inicioI; i < finI; i++){
                for(int j = inicioJ; j > finJ; j--){
                    boss->mesa[i][j] = tabToAdd->casillas[i - (iDiv*5)][j - jDiv*5];
                }
            }  
            break;
        default:
            break;
    }   
}; //pegar los tableros

int buscarIndextabB(admin* boss, char orientacion){
    int ii = -1, n;
    char c;

    switch(orientacion){
        case 'N':
            c = 'S';
            break;
        case 'S':
            c = 'N';
            break;
        case 'E':
            c = 'W';
            break;
        case 'W':
            c = 'E';
            break;
        default:
            break;
    }


    for(int i = 0; i < 9; i++){
        if(boss->idEnMazo[i] == 0){
            if(boss->mazo[i]->tipo == 'T'){ n = 3;
            }else if(boss->mazo[i]->tipo == 'L'){ n = 2;}

            for(int k = 0; k < n; k++){
                if(boss->mazo[i]->bs[k] == c){ ii = i;}
            }
        }
    }
    return ii;
};



void jugar(admin* boss){
    boss->rondasTotal = 1;
    int num, still = 1,aux;
    int pj, cmp,turno = 0;
    char letra;

    int fd[2], df[2];       //father daughter, daughter father con respecto al proceso 1.
    int d1d2[2], d1d3[2], d1d4[2];                       //conexión de pipes entre proceso 1 y hermanos.
    int d2f[2], d3f[2], d4f[2];

    if(pipe(fd) == -1|| pipe(df) == -1 ){
        perror("Error al crear el pipe");
        exit(EXIT_FAILURE);
    }
    if(pipe(d1d2) == -1|| pipe(d1d3) == -1 || pipe(d1d4) == -1){
        perror("Error al crear el pipe");
        exit(EXIT_FAILURE);
    }
    if(pipe(d2f) == -1 || pipe(d3f) == -1 || pipe(d4f) == -1){
        perror("Error al crear el pipe");
        exit(EXIT_FAILURE);
    }


    int id = 1;
    int pid;

    while (id <= 4) {
        pid = fork();
        if (pid == 0) {
            //printf("Hola al mundo! Soy el proceso %d\n\n", id);
            break; // El proceso hijo sale del bucle
        } else if (pid < 0) {
            perror("Error al crear el proceso hijo");
            exit(EXIT_FAILURE);
        }
        id++;
    }
    /*
    if (pid != 0) {
        printf("Este es el proceso padre y mi id es: %d.\n", id);
    }

    printf("                                                TENGO ID: %d\n", id);*/

    if(pid != 0){//padre
        cmp = turno % 4;
        while(still == 1){
            sleep(2);
            printf("\n      --- Turno actual: J%d ---\n\n", (turno%4)+1);

            mostrarSuperTablero(boss);
            mostrarManoJ(boss, cmp);

            switch(cmp){
                case 0:
                    //printf("\n        Leyendo proceso %d\n",cmp+1);
                    read(df[0], &letra, sizeof(letra));
                    read(df[0], &num, sizeof(num));
                    
                    //printf(">>> Recibido letra: %c y num: %d del proceso %d\n", letra, num, cmp+1);
                    modificacionTurno(boss, cmp,letra, num);

                    break;
                case 1:
                    //printf("        Leyendo proceso %d\n",cmp+1);
                    read(d2f[0], &letra, sizeof(letra));
                    read(d2f[0], &num, sizeof(num));
                    
                    //printf(">>> Recibido letra: %c y num: %d del proceso %d\n", letra, num, cmp+1);

                    modificacionTurno(boss, cmp, letra, num);
                    break;
                case 2:
                    //printf("\n        Leyendo proceso %d\n",cmp+1);

                    read(d3f[0], &letra, sizeof(letra));
                    read(d3f[0], &num, sizeof(num));
                    
                    //printf(">>> Recibido letra: %c y num: %d del proceso %d\n", letra, num, cmp+1);

                    modificacionTurno(boss, cmp, letra, num);
                    break;
                case 3:
                    //printf("\n        Leyendo proceso %d\n",cmp+1);

                    read(d4f[0], &letra, sizeof(letra));
                    read(d4f[0], &num, sizeof(num));
                    
                    //printf(">>> Recibido letra: %c y num: %d del proceso %d\n", letra, num, cmp+1);

                    modificacionTurno(boss, cmp, letra, num);
                    break;
            }
            printf("\n");
            mostrarSuperTablero(boss);
            printf("\n      --- Turno finalizado ---\n");
            turno += 1;
            cmp = turno % 4;
            if(cmp == 0){
                //printf("\n\nEvaluando si terminar la partida...\n");
                aux = comprobarVictoria(boss,turno);
                if(aux == -1 || aux == 0){still = 0;}
                write(fd[1],&still, sizeof(still));
                }
            
        }
        //printf("                                                                                         fin proceso padre!\n");
    }else if(id == 1){
        pj = 0;
        cmp = pj % 4;
        while(still == 1){
            sleep(3);

            switch(cmp){
                case 0:
                    printf("        Dando indicaciones al jugador 1...\n");
                    printf("Ingrese carta:");
                    scanf(" %c", &letra);
                    if(letra == 'B' || letra == 'E' || letra == 'R'){
                        num = -1;
                    }else{
                        printf("Ingrese N° Pasos:");
                        scanf("%d", &num);}

                    write(df[1], &letra, sizeof(letra));
                    write(df[1], &num, sizeof(num));

                    break;
                    
                case 1:
                    write(d1d2[1], &still, sizeof(still));

                    printf("        Dando indicaciones al jugador 2...\n");
                    printf("Ingrese carta:");
                    scanf(" %c", &letra);
                    if(letra == 'B' || letra == 'E' || letra == 'R'){
                        num = -1;
                    }else{
                        printf("Ingrese N° Pasos:");
                        scanf("%d", &num);}

                    write(d1d2[1], &letra, sizeof(letra));
                    write(d1d2[1], &num, sizeof(num));
                    
                    break;

                case 2:
                    write(d1d3[1], &still, sizeof(still));

                    printf("        Dando indicaciones al jugador 3...\n");
                    printf("Ingrese carta: ");
                    scanf(" %c", &letra);
                    if(letra == 'B' || letra == 'E' || letra == 'R'){
                        num = -1;
                    }else{
                        printf("Ingrese N° Pasos: ");
                        scanf("%d", &num);}

                    write(d1d3[1], &letra, sizeof(letra));
                    write(d1d3[1], &num, sizeof(num));

                    break;

                case 3:
                    write(d1d4[1], &still, sizeof(still));

                    printf("        Dando indicaciones al jugador 4...\n");
                    printf("Ingrese carta: ");
                    scanf(" %c", &letra);
                    if(letra == 'B' || letra == 'E' || letra == 'R'){
                        num = -1;
                    }else{
                        printf("Ingrese N° Pasos: ");
                        scanf("%d", &num);}

                    write(d1d4[1], &letra, sizeof(letra));
                    write(d1d4[1], &num, sizeof(num));
                    break;

                default:
                    break;

            }
            
            pj += 1;
            cmp = pj % 4;
            if (cmp == 0){read(fd[0], &still, sizeof(still));}
        }
        write(d1d2[1], &still, sizeof(still));
        write(d1d3[1], &still, sizeof(still));
        write(d1d4[1], &still, sizeof(still));

        //printf("                                                                                            fin proceso 1\n");
        exit(0);
    }else if(id < 5){
        //printf("                                                                        Hola desde el proceso %d a trabajar!\n", id);

        while(still == 1){
            still = 0;
            switch(id){
                case 2:
                    read(d1d2[0], &still, sizeof(still));

                    if(still == 1){
                        read(d1d2[0], &letra, sizeof(letra));
                        read(d1d2[0], &num, sizeof(num));

                        //printf("Soy %d y estoy pasándole %c y %d al padre\n",id, letra, num);
                        write(d2f[1], &letra, sizeof(letra));
                        write(d2f[1], &num,  sizeof(num));
                    }
                    

                    
                    break;
                case 3:
                    read(d1d3[0], &still, sizeof(still));

                    if(still == 1){
                        read(d1d3[0], &letra, sizeof(letra));
                        read(d1d3[0], &num, sizeof(num));

                        //printf("Soy %d y estoy pasándole %c y %d al padre\n",id, letra, num);
                        write(d3f[1], &letra, sizeof(letra));
                        write(d3f[1], &num,  sizeof(num));
                    }
                    
                    
                    break;
                case 4:
                    read(d1d4[0], &still, sizeof(still));

                    if(still == 1){
                        read(d1d4[0], &letra, sizeof(letra));
                        read(d1d4[0], &num, sizeof(num));

                        //printf("Soy %d y estoy pasándole %c y %d al padre\n",id, letra, num);
                        write(d4f[1], &letra, sizeof(letra));
                        write(d4f[1], &num,  sizeof(num));
                    }
                    
                    break;
            }
        }
        //printf("                                                                                            fin proceso %d\n",id);
        exit(0);
    }
 
    int status;
    for (int i = 0; i < 4; i++) {
        waitpid(-1, &status, 0);
        if (WIFEXITED(status) && i != 0) {
            printf("Bot %d se desconectó de la partida...\n", i+1);
        }
    }
    if(aux == -1){
        printf( "\n\n       --- FIN DE LA PARTIDA ---\n"
                "Te has quedado sin turnos... puedes volver a intentarlo!\n");
    }else if(aux == 0){
        printf( "\n\n       --- FIN DE LA PARTIDA ---\n"
                "¡Felicidades! has GANADO. Eres un profesional!\n");
    }
};

int comprobarVictoria(admin* boss, int turnos){                     //1 si se sigue jugando, 0 si es victoria, -1 si se para el juego por turnos

    int r = 1;
    int bu = 0;

    for(int i = 0; i < 4; i++){
        if(boss->jugadores[i]->tesoro == 0){
            bu = 1;
        }
    }

    if(bu == 0){r = 0;}
    if(turnos/4 == boss->rondasTotal){r = -1;}

    return r;
};

void modificacionTurno(admin* boss, int idP, char letra, int num){
    player* pj = boss->jugadores[idP];

    if(num == -1){
        //funciones de buscar, escalera y recoger.
        casilla tmp = boss->mesa[pj->pos[0]][pj->pos[1]];
        switch(letra){
            case 'B':           //buscar mapa
                
                char or = tmp.repSecundaria;
                int ii = buscarIndextabB(boss, or);
                if(ii != -1){
                    addTablero(boss, ii, (idP + 1), or);
                }else{printf("  >> Te quedaste sin cartas en el mazo! <<\n");}
                
                break;
            case 'E':           //abrir puerta.  
                if(tmp.elem == ESCALERAS){
                    boss->mesa[pj->pos[0]][pj->pos[1]] = crearCasilla('0');
                }
                break;
            case 'R':           //recoger tesoro.
                if(tmp.elem == TESORO && tmp.numJugador == idP+1){
                    boss->mesa[pj->pos[0]][pj->pos[1]] = crearCasilla('0');
                    boss->jugadores[idP]->tesoro = 1;
                }
                break;
            default:
                break;
        }   
    }else{
        mover(boss, idP, letra, num);
    }
};

void mover(admin *boss,int idP, char dir, int num){
    player* pj = boss->jugadores[idP];

    int modij = -1, op = 0;
    casilla tmp;

    switch(dir){
        case 'W':
            op = -1;
            modij = 0;
            break;
        case 'A':
            op = -1;
            modij = 1;
            break;
        case 'S':
            op = 1;
            modij = 0;
            break;
        case 'D':
            op = 1;
            modij = 1;
            break;
        default:
            break;
    }

    for(int i = 0; i < num; i++){
        pj->pos[modij] += 1*(op);

        tmp = boss->mesa[pj->pos[0]][pj->pos[1]];

        if(tmp.elem == CAMARA){
            boss->mesa[pj->pos[0]][pj->pos[1]] = crearCasilla('0');
            boss->camActivasST -= 1;
        }else if(tmp.elem == BONUS){
            boss->mesa[pj->pos[0]][pj->pos[1]] = crearCasilla('0');
            if(boss->camActivasST < 2){boss->rondasTotal += 5;}
        }else if(tmp.elem == notBONUS){
            boss->mesa[pj->pos[0]][pj->pos[1]] = crearCasilla('0');
            boss->rondasTotal -= 3;
        }else if((tmp.elem == TP) && (tmp.numJugador == idP+1)){
            //verificarTp();
        }
    }
};