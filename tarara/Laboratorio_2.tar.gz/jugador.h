#ifndef JUGADOR_H
#define JUGADOR_H

#include "tablero.h"

typedef struct{
    casilla cas;
    int pos[2];
    char card;
    int tesoro;

} player;

typedef struct {
    int rondasTotal;
    player **jugadores;
    tesoroCheck *checkT;
    camarasCheck *checkC;
    casilla **mesa;
    tablero** mazo;
    int inicioI;
    int finI;
    int inicioJ;
    int finJ;
    int camActivasST;
    int idEnMazo[9];        //id del tablero es el índice, y se indica un 1 si ya se ocupó o un 0 si no.
} admin;


player *crearPlayer(int p[2], casilla c);
void asignarCartas(admin* boss);
admin* crearAdmin();

char *mezclarMazoAccion(); //se mezcla el mazo de 'B' y 'E'
int buscarPosJ(admin* boss, int i, int j);

casilla **crearSuperTablero(admin* boss, int ii);

int buscarIndextabB(admin* boss, char Orientacion);
void addTablero(admin* boss, int indexToAdd,  int numJ, char orientacion);

void mostrarSuperTablero(admin* juego);

void mostrarManoJ(admin* boss, int ii);

void jugar(admin* boss);

void mover(admin *boss,int idP, char dir, int num);
int verificarTp(int x, int y, player *jugador, admin boss);
int comprobarVictoria(admin* boss, int turnos);

void modificacionTurno(admin* boss, int idP, char letra, int num);

#endif /*JUGADOR_H*/