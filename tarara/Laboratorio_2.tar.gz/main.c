#include <stdio.h>
#include <stdlib.h>
#include "tablero.h"
#include "jugador.h"


int main(){

    admin* boss = crearAdmin();                                             //se crea el administrador del juego.

    char** nameTabs = nombreTableros();                                     //se obtienen los nombres de los archivos txt que contienen los mazos.
    boss->mazo = listaTableros(nameTabs, boss->checkT, boss->checkC);       //se crea la lista de tableros, inicializandolos y generando las casillas especiales.

    shuffle(boss->mazo);                                                           //se mezcla el mazo de cartas.

    int ii = buscarIndexInicio(boss->mazo);                                       //se busca el índice del tablero inicial en la lista generada anteriormente.
    boss->mesa = crearSuperTablero(boss, ii);                         //se crea el tablero que se irá actualizando y se recupera la posición de los jugadores.
    
    if(boss->checkT->ganable == 0){
        printf("\n\n                    Las cartas de tablero no generaron "
                "los trofeos mínimos para ganar.\n");
        printf("                                            Fin del Juego.\n\n");
        exit(1);
    }else{
        printf("\n\n                    Que comience el juego! \n");
        asignarCartas(boss);                                            //asignación de cartas a los jugadores.
        
        jugar(boss);
    }

    
    

    return 0;
}