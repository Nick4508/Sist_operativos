#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include "tablero.h"

tablero *crearTablero(int num){ 
    tablero *board = malloc(sizeof(tablero));
    board->filas = 5;               //inf redundante
    board->columnas = 5;
    board->inicio = 0;
    board->num = num;

    board->casillas = (casilla **) malloc(5*sizeof(casilla *));
    for (int i = 0; i < 5; i++){
        board->casillas[i] = (casilla *) malloc(5*sizeof(casilla));
    }

    return board;
};
tablero **listaTableros(char** nameList, tesoroCheck* checkT, camarasCheck* checkC){
    
    tablero** list = (tablero **) malloc (9*sizeof(tablero*));

    for(int i = 0; i < 9; i++){
        list[i] = guardarTablero(nameList[i], i,checkT, checkC); 
    }

    return list;
};

tablero *guardarTablero(char* nombreTablero,int num, tesoroCheck* checkT, camarasCheck* checkC){ //son 9 tableros siosi. hay que pasar por referencia checkT y el checkC

    size_t longitud = strlen(nombreTablero);

    int largoRuta = (int)longitud + strlen(".txt") + 1;
    int contador = 0, tmp; 
    char ruta[largoRuta], bs[3];
    snprintf(ruta, sizeof(ruta), "%s.txt", nombreTablero);

    FILE* archivo = fopen(ruta, "r");

    if(archivo == NULL){
        printf("Error al abrir el archivo\n");
        exit(1);
    }

    tablero *tabCard = crearTablero(num);
    
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            char c;
            do {
                c = fgetc(archivo);
            } while (c == ' ' || c == '\n' || c == '\r'); // Salta los espacios

            if (c != 'J'){
                
                tabCard->casillas[i][j] =  crearCasilla(c);
                if(c == 'B'){
                    c = identificarBuscar(i,j);
                    bs[contador++] = c;
                    tabCard->casillas[i][j].repSecundaria = c;
                }

            } else if (c == 'J'){
                tabCard->inicio = 1;
                tmp =fgetc(archivo) - '0';
                tabCard->casillas[i][j] = crearCasillaJ(c, tmp);
            }
        }
    }
    fclose(archivo);
    char *bsT = (char *) malloc (contador*sizeof(char));
    tabCard->bs = bsT;

    for(int k = 0; k < contador; k++){          //se indica en dónde están los buscar (N,S,W,E)
        tabCard->bs[k] = bs[k];
    }
    if(contador == 2){tabCard->tipo = 'L';          //se indica el tipo de tablero
    }else if(contador == 3){tabCard->tipo = 'T';}

    //aquí se buscará crear la casilla especial sí y sólo si el tablero no es inicial

    if(tabCard->inicio == 0){
        generarEspecial( tabCard, checkT, checkC);
    }


    return tabCard;
}; //leer txt


void generarEspecial(tablero* tabCard, tesoroCheck* checkT, camarasCheck* checkC){        //pasar por referencia TODO!.

    srand(time(NULL));

    int generada = 0, i, j, x;

    while(generada == 0){
        i = rand() % 1000;
        i = i%5;
        j = rand() % 1000;
        j = i%5;
        
        if(tabCard->casillas[i][j].elem == VACIO){
            generada = 1;
        } 
    }

    x = rand() % 100 + 1;

    if( (x <= 50) && (checkT->cantidad < 4) ){
        generada = 0;
        while(generada == 0){
            x = rand() % 1000;
            x = x%4;
            if(checkT->jTesoro[x] == 0){
                tabCard->casillas[i][j].elem = TESORO;
                tabCard->casillas[i][j].representacion = 'T';           //ver tiktok de si un jugador puede recolectar un puro tesoro que tiene "su nombre".
                tabCard->casillas[i][j].numJugador = x + 1;             // ojo que los jugadores se están modelando como que parten del
                printf("            el jugador %d tiene un tesoro asignado\n", tabCard->casillas[i][j].numJugador);
                generada = 1;

                (checkT->cantidad)++;
                checkT->jTesoro[x] = 1;
                if(checkT->cantidad == 4){ checkT->ganable = 1; }

            }
        }
        
    }else{
        x = rand() % 1000;
        x = x%3;
        switch (x)
        {
        case 0:
            tabCard->casillas[i][j].elem = CAMARA;
            tabCard->casillas[i][j].representacion = 'b';
            tabCard->casillas[i][j].repSecundaria = 'c';
            
            (checkC->camarasActivas)++;         //se aumenta cantidad de cámaras
            checkC->camTab[tabCard->num] = 1;
            break;

        case 1:
            tabCard->casillas[i][j].elem = BONUS;
            tabCard->casillas[i][j].representacion = 'b';
            tabCard->casillas[i][j].repSecundaria = 't';
            break;

        case 2:
            tabCard->casillas[i][j].elem = notBONUS;
            tabCard->casillas[i][j].representacion = 'b';
            tabCard->casillas[i][j].repSecundaria = 'n';
            break;

        case 3:
            tabCard->casillas[i][j].elem = TP;
            tabCard->casillas[i][j].representacion = 't';       //incluir el readme la mutación de nombres porque algunos cambiaron.
            tabCard->casillas[i][j].repSecundaria = ' ';

            x = rand() % 1000;
            x = x%4 + 1;
            tabCard->casillas[i][j].numJugador = x;
            break;

        default:
            break;
        }

    }

};

char identificarBuscar(int i, int j){
    if(j == 2){
        if(i == 0){return 'N';}
        if(i == 4){return 'S';}
        }

    if(i == 2){
        if(j == 0){return 'W';}
        if(j == 4){return 'E';}
    }

    return 'F';    
};

casilla crearCasilla(char c){
    
    casilla r;
    
    switch (c)
            {
            case '/':
                r.elem = MURO;
                r.representacion = '/';
                r.repSecundaria = ' ';
                r.numJugador = -1;
                break;
            case 'E':
                r.elem = ESCALERAS;
                r.representacion = 'E';
                r.repSecundaria = ' ';
                r.numJugador = -1;
                break;
            case '0':
                r.elem = VACIO;
                r.representacion = '0';
                r.repSecundaria = ' ';
                r.numJugador = -1;
                break;
            case 'B':
                r.elem = BUSCAR;
                r.representacion = 'B';
                r.repSecundaria = ' ';
                r.numJugador = -1;
                break;
            case '*':
                r.representacion = '*';
                r.repSecundaria = ' ';
                r.numJugador = -1;
                break;

            default:
                break;
            }

    return r;
};

casilla crearCasillaJ(char c, char num){
    
    casilla r;
    r.elem = JUGADOR;
    r.representacion = c;
    r.repSecundaria = ' ';
    r.numJugador = num;

    return r;
    
};

char **nombreTableros(){

    char **labNames = (char**) malloc (9*sizeof(char*));
    
    DIR *dir;
    struct dirent *ent;
    const char *extension = ".txt", *readme = "README";

    dir = opendir("."); // Abrir el directorio actual
    
    if (dir) {
        int pos = 0;
        while ((ent = readdir(dir)) != NULL) {
            if (strstr(ent->d_name, extension) != NULL && strstr(ent->d_name, readme) == NULL){
                size_t longitud = strnlen(ent->d_name, sizeof(ent->d_name));

                int n = ((int) longitud) - 4; 
                char *aux = (char *)malloc((n + 1) * sizeof(char));

                if (aux == NULL) {
                    perror("Error al asignar memoria para aux");
                    exit(EXIT_FAILURE);
                }

                strncpy(aux, ent->d_name, n);
                aux[n] = '\0';
                printf("%s\n", aux);

                labNames[pos++] = strdup(aux);

            }
        }
        closedir(dir);
    }
    return labNames;
};

void mostrarTablero(tablero *tablero){

    char c;
    
    for(int i=0; i<tablero->filas; i++){
        for(int j=0; j<tablero->columnas; j++){
            
            if(tablero->casillas[i][j].numJugador == -1){
                if(tablero->casillas[i][j].representacion == 'B'){ c = ' ';
                        }else{c = tablero->casillas[i][j].repSecundaria;}

                printf("%c%c ", tablero->casillas[i][j].representacion, c);
            }else{
                printf("%c%d ",tablero->casillas[i][j].representacion, tablero->casillas[i][j].numJugador);
            }
        }
        printf("\n");
    }
};
  //mostrar tablero


tesoroCheck* crearTesoroCheck(){
    tesoroCheck* r = (tesoroCheck *) malloc (sizeof(tesoroCheck));

    r->ganable = 0;
    r->cantidad = 0;
    r->jTesoro[0] = 0;
    r->jTesoro[1] = 0;
    r->jTesoro[2] = 0;
    r->jTesoro[3] = 0;

    return r;
};

camarasCheck* crearCamaraCheck(){
    camarasCheck* r = (camarasCheck *) malloc (sizeof(camarasCheck));

    r->camarasActivas = 0;

    for(int i = 0; i < 9; i++){
        r->camTab[i] = 0;
    }

    return r;
};

int buscarIndexInicio(tablero** tabList){
    int index = -1;
    for(int i = 0; i < 9; i++){
        if(tabList[i]->inicio == 1){
            index = i;
        }
    }

    return index;
};

void shuffle(tablero** mazo) {
    srand(time(NULL));
    int j;
    tablero* temp;
    // Comienza desde el último elemento y va hacia atrás
    for (int i = 8; i > 0; i--) {
        //printf("Mezclando el %d° tablero\n", mazo[i]->num);
        // Genera un índice aleatorio entre 0 y i (inclusive)
        j = rand() % 1000;
        j = j % (i + 1);

        temp = mazo[i];
        mazo[i] = mazo[j];
        mazo[j] = temp;
    }
};