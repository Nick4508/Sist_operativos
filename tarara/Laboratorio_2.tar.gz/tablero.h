#ifndef TABLERO_H
#define TABLERO_H

typedef enum{
    JUGADOR,
    TESORO,
    BUSCAR,
    ESCALERAS,
    MURO,   
    CAMARA,
    CAMARAInactiva,
    BONUS, //Añade 5 turnos.
    notBONUS, //añade 4 turnos.
    TP,
    VACIO
}tipo; 

typedef struct {
    tipo elem;
    char representacion; 
    char repSecundaria; 
    int numJugador; //si no el elemento en la casilla no es un jugador, entonces numJugador vale -1.
} casilla;


typedef struct{
    int ganable; //1 si, 0 si no se puede ganar por tesoros faltantes.
    int jTesoro[4]; //indice del arreglo-> jugador-1, valor en la casilla 0->sin tesoro asignado/ 1-> con tesoro asignado.
    int cantidad; //total de tesoros generados.
} tesoroCheck;

typedef struct{
    int camarasActivas;
    int camTab[9]; // posición i-> id del tablero, 0 si no hay cámara, 1 si la hay.
} camarasCheck;


typedef struct {
    int num;
    int inicio;
    int filas;
    int columnas;
    casilla **casillas;
    char tipo;      //de tipo T o L
    char* bs;        // arreglo de char indicando donde tienen la 'B' N,S,E,W  (se asume que siempre estarán las B's en el centro de los lados)
} tablero;

char **nombreTableros();
tablero *crearTablero(int num);

char identificarBuscar(int i, int j);

tablero **listaTableros(char** nameList, tesoroCheck* checkT, camarasCheck* checkC);
void shuffle(tablero** mazo);
tablero *guardarTablero(char* NombreTablero, int num, tesoroCheck* checkT, camarasCheck* checkC);
void generarEspecial(tablero* tabCard, tesoroCheck* checkT, camarasCheck* checkC);

void mostrarTablero(tablero *tablero);


casilla crearCasilla(char c); //casillas normales
casilla crearCasillaJ(char c, char num); //casillas jugador
casilla crearCasillaB(char c, char or);  //casilla buscar


tesoroCheck* crearTesoroCheck();
camarasCheck* crearCamaraCheck();

int buscarIndexInicio(tablero** tabList);

#endif /*TABLERO_H*/